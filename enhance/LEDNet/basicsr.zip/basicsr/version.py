# GENERATED VERSION FILE
# TIME: Wed Dec 18 21:58:45 2024
__version__ = '1.3.2'
__gitsha__ = '9fa3c0a'
version_info = (1, 3, 2)
